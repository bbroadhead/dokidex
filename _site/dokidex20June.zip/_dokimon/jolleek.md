---
number: 11
name: Jolleek
lang_names: []
stage: 2
evolves_at: 15
type:
- Light
location: Passaway Caves, Route 01, Which-way Caves
image: /assets/images/jolleek.png
description: ''
long_description: Although occasionally found leading small armies of Furreal, Jolleek
  can actually be quite gentle, and good with children.
short_description: Role Model Dokimon
base_stats:
- 33
- 80
- 64
- 42
- 61
- 101
evo_chain_include: furreal_chain.html
---
